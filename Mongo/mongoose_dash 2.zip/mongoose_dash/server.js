var express = require("express");
console.log('*******1')
var path = require("path");
console.log('*******2')
var app = express();
console.log('*******3')
var session = require('express-session');
console.log('*******4')
var bodyParser = require('body-parser');
console.log('*******5')

app.use(bodyParser.urlencoded({ extended: true }));
console.log('*******6')
app.use(express.static(path.join(__dirname, "./client/static")));
app.set('views', path.join(__dirname, './client/views'));
app.set('view engine', 'ejs');
console.log('*******7')
app.set('views', path.join(__dirname, './client/views'));
app.set('view engine', 'ejs');
console.log('*******8')
require('./server/config/mongoose.js');
var routes_setter = require('./server/config/routes.js');
routes_setter(app);
console.log('*******9')
app.listen(8001, function () {
    console.log("listening on port 8001");
})