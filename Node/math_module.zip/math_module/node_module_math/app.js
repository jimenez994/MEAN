var math_module = require('./mathlid')();     //notice the extra invocation parentheses!

math_module.add(1,24);
math_module.multiply(2,3)
math_module.square(3);
math_module.random(1,100);
