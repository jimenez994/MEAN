import { SearchQPipe } from './search-q.pipe';

describe('SearchQPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchQPipe();
    expect(pipe).toBeTruthy();
  });
});
