export class Answer {
    _id: string;
    answer: string;
    detail: string;
    _question: string;
    _user: string;
}
