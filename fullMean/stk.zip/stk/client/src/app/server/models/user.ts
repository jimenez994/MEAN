export class User {
    _id: string;
    email: string;
    first_name: string;
    last_name: string;
    password: string;
    password_confirm: string;
    _question: any;
    _answer: any;
}
