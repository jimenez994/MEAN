export class Question {
    _id: string;
    question: string;
    description: string;
    _answer: any;
    _user: string;
}
